Hi theis Tejas Vinay B,
Download Javascript,CSS,html code 
zip file imclude icons and font pacakge.
run index.html file.
software used to develope ; Brackets.

could complete objectives:
impilmenting api access to current location temperature in °c.
ability to switch units °c to f and vice versa.
Current city weather temperature and description including icons.
Search cities weather temperature and decription of weather.

coudlnt complete:
graph and historical data.
comparetive city graphs.
